# Unified search verification — 2026-10-24

Source checks pass for54 generated HTML pages,4711 local references and53 unchanged product component documents after the declared behavior/stylesheet substitutions. The previous75-file Browse First release and entire preserved dependency chain verify byte-for-byte. JavaScript syntax passes Node's check.

In-app Chromium verifies live desktop counts, one-result and zero-result submissions, Reset all draft behavior and recovery, inclusive date bounds, OR categories, invalid-range blocking, Enter submission, tablet count updates and cancellation, phone submission/event navigation/Back, and node restoration when an open tablet drawer becomes desktop. There remains one query and one status region across sizes.

At1440×900, header, rail, event list and individual-event rectangles are identical to Browse First. The desktop dock grows internally to hold the live count/reset row; its bottom and the list bottom remain852px. At1200×600 they both end at552px, retaining48px of bottom breathing room. No horizontal overflow was observed. Tablet1024×768 and phone390×844 retain the existing flyout arrangement and behavior.

`browser-check.json` contains observed values and18 derived passing checks. Screenshots: `desktop-live-count.png` and `tablet-live-count.png`, both showing the same one-event draft preview. This verifies the local responsive prototype in Chromium; physical keyboards/devices, screen readers and direct Firefox/Safari runs remain outside this pass. The implementation adds no new browser API beyond the previously tested controller.
