# Margin Reveal · Unified search

[Responsive prototype](http://127.0.0.1:4187/margin-reveal-unified-search/demo/index.html) · [Three-size review](http://127.0.0.1:4187/margin-reveal-unified-search/index.html) · [Preserved Browse First](http://127.0.0.1:4187/margin-reveal-browse-first/index.html)

The user prefers the tablet flyout's live matching count and one combined action. This sibling extends that exact interaction to desktop. It preserves the previous release rather than overwriting it.

## Shared interaction contract

- Search has no separate submit button while enhanced. Typing, clearing the query, changing dates and selecting categories update the matching count and Show N events label immediately.
- The status is the same polite, atomic live region at every width. The existing TideSearch rules match all query words, inclusive From/Through dates and any selected category. All48 sample cards are counted, including those hidden by the applied URL.
- One Show events action applies query, dates and categories together through the existing GET form. Enter in search also submits. The feed and URL stay on the applied choices until submission.
- Reset all clears the entire draft and restores a48-event preview. It does not navigate until Show events. The native search clear control also updates the count.
- Invalid ranges retain the existing visible explanation and native validity; the status says Check the date range and the action says Check dates. Zero matches remain a valid submission with the original empty state and recovery.
- Mobile/tablet retain the left modal flyout. Cancel, Escape and backdrop dismissal restore the opening query/filter values. Desktop retains the original persistent rail and its existing open/close behavior.
- The existing Clear all link remains in applied context. The redundant link beside the desktop submit is hidden while enhanced because Reset all occupies that action area. Without the enhancement, the original separate submits, native disclosure and Clear all remain usable.

## Placement and ownership

There is one query, one set of date/category controls, one status/reset row and one apply button. `unified-search.js` derives from the preserved Browse First controller and replaces it in these documents. Direct input/change listeners follow the original nodes between containers; the count implementation is shared at all widths. Below75rem the controls and actions live in the existing dialog. At75rem and above the status/reset row moves to the existing desktop dock above the original apply button. It returns before the frozen desktop adapter removes the dock during resizing. Open mobile drafts cancel on crossing to desktop, as in the previous release.

`unified-search.css` owns the private desktop status-row layout, caption typography, full-width apply, redundant-link visibility and the1.0.1 spacing refinement. It consumes existing semantic tokens, adds no color or sizing primitives, and does not redefine kit control internals. Desktop header, horizontal rail/list/event geometry, left alignment and right document scroll continue to use their preserved CSS sources. At75rem and above, both bounded panes now use the column-gap token as their bottom clearance (currently24px). The dock's start inset and the gap below its Reset all row both use space4 (16px); the original grid keeps Show events aligned with the list bottom. The scrollable filter body absorbs the footer size change. Smaller-screen styles are unchanged.

This app composition has an HTML/CSS/behavior home and registration in `component-candidates.json`. The maintained kit and frozen foundation are unchanged. Broader kit adoption still needs shared-shell consolidation, all-theme specimens and device/assistive-technology verification, with removal of app duplicates. No React or service has been added.

## Build and preservation

Run Python `-B tools/build.py`, then `-B tools/check.py`; run `-B tools/package.py` after browser QA. The54 generated HTML documents preserve the original component markup after removing the declared script/stylesheet substitutions. Verification checks the previous75-file release and the entire preservation chain. Only this sibling receives new QA and packaging output. Browser evidence is recorded under `qa/`.

Version1.0.0 remains preserved in its original68-file release archive and checksum. Version1.0.1 changes only the two desktop spacing relationships above; its browser measurements live in `qa/spacing-1.0.1.json`. The earlier behavioral evidence remains the1.0.0 baseline.
