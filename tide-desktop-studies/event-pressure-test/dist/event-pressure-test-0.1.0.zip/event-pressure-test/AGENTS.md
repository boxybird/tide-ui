# Event pressure test

Separate copy of the user-approved Shared Filters baseline. Never write to `../shared-filter-release/`, its kit or earlier studies. Its complete 283-file lock must pass before/after work. Use Python `-B`; avoid bytecode in frozen imports.

This is a UI pressure test with authored sample data, not collection of real submissions or a backend/PWA implementation. Preserve baseline type, spacing, themes, controls, touching cards, unframed panes, header, Margin Reveal widths, native scrollbar measurement and responsive filter behavior. Consume the frozen kit directly. New study compositions belong to `tide-pressure`; review presentation to `tide-pressure-review`.

Priorities 1–3 only: messy event metadata, lifecycle states and simulated loading/recovery. Reuse Badge, Notice, Empty, Date, Card, Hero, Details, Summary, Field and Button. Document new compositions and conditional-data rules here; adoption into a kit release needs user acceptance later. Do not mutate the accepted kit during this experiment.

Build with tools/build.py. Checks must verify source/links/semantics, interval filtering and baseline hashes. Actual browser evidence is Chromium; Firefox/Safari remain deferred. Preserve local-only operation and all earlier releases.
