"""Snapshot this experiment; no writes to its frozen baseline dependency."""
from pathlib import Path
import hashlib
import json
import zipfile

root=Path(__file__).resolve().parents[1]
files=sorted(p for p in root.rglob('*') if p.is_file() and 'dist' not in p.relative_to(root).parts and '__pycache__' not in p.parts)
inventory={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
dist=root/'dist';dist.mkdir(exist_ok=True)
manifest={'version':'0.1.0','kind':'UI pressure-test experiment, not an approved baseline','baseline':'../shared-filter-release/ (283-file frozen release)','runtimeDependency':'Keep the existing sibling shared-filter-release/kit/ and the local study server; this is a study snapshot, not a standalone deployment.','files':inventory}
(dist/'inventory-0.1.0.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
archive=dist/'event-pressure-test-0.1.0.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,Path('event-pressure-test')/p.relative_to(root))
checksum=hashlib.sha256(archive.read_bytes()).hexdigest()
(dist/'event-pressure-test-0.1.0.sha256').write_text(checksum+'  '+archive.name+'\n',encoding='utf-8')
print(json.dumps({'files':len(files),'archive':archive.name,'sha256':checksum},indent=2))
