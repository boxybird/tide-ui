# Half Split · List Rhythm

Open <http://127.0.0.1:4187/list-rhythm/index.html> to compare three desktop refinements of the preserved Pinned Apply layout:

1. **Lineup** makes the live result count the column heading. The month and its count remain a quieter sticky anchor.
2. **Calendar** leads with the month, a separate year, and the existing neutral Badge for the month count. Total results and ordering are secondary.
3. **Month Index** gives each month a real numeric marker, echoing Date Line's prominent dates. The year, count and month navigation remain beside it.

All three use the same 48 events, cards, controls, Half Split widths, Bumble Dark tokens and sticky header. These are private desktop composition studies, not changes to the maintained UI kit. Earlier studies, the app and the kit are preserved.

Latest refinement (1.0.1): **Lineup is the selected favorite.** Its Apply dock has one additional 8px spacing step above the controls (24px total), giving the actions more room while preserving their bottom alignment and the 48px viewport gap. The adjustment starts at the existing desktop breakpoint; the other two variations are unchanged. At 1440 × 900, Apply and the list still end at y=852. Source checks pass. Evidence is saved as `qa/lineup-spacing-1.0.1.*`, and the source release is `dist/list-rhythm-1.0.1.zip`. The original 1.0.0 archive retains the preceding design.

## Spacing and alignment

The top gap stays at the existing spacing token: 24px below the header. The bottom gap becomes twice that token: 48px. Both left panels use `100dvh - panel top - bottom gap`, so they remain bounded by the viewport while the right event follows the natural document scroll. The list keeps this height for one result and empty results, too; it does not shrink away from the dock alignment.

The Apply/Clear action row remains docked outside the filter-options scroller. Its lower padding is removed so the **controls' bottom edge**, the filter panel bottom and the event-list bottom align. The dock keeps its original upper space, inline inset and neutral separator. No outer panel frame is added.

The original Results top rule and sticky month header bottom rule are removed in these studies. Card-to-card separators remain unchanged. The larger sticky headings measure their actual height with ResizeObserver and feed that value into the list's scroll padding to keep keyboard targets visible.

## Component ownership

`list-rhythm.css` owns only private `tide-feed-study` classes and the preceding private action dock. All type sizes, spacing, weights and colors consume existing semantic tokens. It does not redefine shared kit tokens; it overrides only the preceding study's private panel-height variable. No new font family, color palette or kit component is introduced.

`headings.js` composes the original live result-count node and original month H3/count nodes after the preserved search helper runs. Their IDs, status semantics, count values and month jump links stay intact. The numeric month is decorative (`aria-hidden`); the accessible month heading still contains the month, year and result count. Calendar reuses the existing `tide-badge` class.

The adapter restores the original heading text nodes below 75rem/1200px. Mobile and tablet keep the approved source layout and components. This script handles composition only; native GET search, inclusive dates, categories, validation, empty states, clear actions and event navigation remain owned by the preserved app.

## Build and preservation

Run from this folder with Python's `-B` option:

```text
python -B tools/build.py
python -B tools/build.py --check
python -B tools/check.py
node --check headings.js
```

Use the existing parent preview server on port 4187. Do not run parent, app or kit writers. `tools/context.py` checks all previous source archive hashes and locked source inventories before and after work. This folder depends on its preserved siblings and the adjacent app; its source release is not a standalone application distribution.

## Verification · 2026-10-22

All 160 HTML pages pass the source and reference checks (12,355 local references). After removing only declared private classes, data attributes and stylesheet/script references, the 159 product documents match the preserved Pinned Apply generator. JavaScript syntax passes. Preservation checks cover 185 original desktop-study files, 177 width-study files, 177 prior refinement files, 980 app files and 180 kit files. No kit component was added or edited.

Rendered checks used the in-app Chromium browser. At 1440 × 900, the header remains at y=0, both left panels start at y=117, and the panels and Apply controls end at y=852. This keeps the original 24px top gap and creates the requested 48px bottom gap. The 1200 × 800 and 1920 × 1080 checks retain the Half Split tracks and the same 48px bottom clearance, without horizontal page overflow. Scrolling the right document to its end leaves the header and left panels in place; scrolling filter options leaves Apply available.

The November boundary was checked at the narrow desktop width, including the longer month name, the 11 marker, count and navigation. Combined November 12 date/category filters produce one workshop; a nonmatching query produces zero results; clear returns all 48. Both one-result and empty lists retain the same viewport height and dock alignment. A long query wraps in caption-sized supporting text instead of becoming an oversized heading.

At 390 × 844 and 1024 × 768, header, list and first-card geometry match the preserved baseline exactly. Desktop-to-tablet restoration removes the composed headings and dock in all three variants. Calendar remounts without duplicate counts, badges or Apply controls.

The comparison page provides three working HTML frames and 1200/1440/1920 preview-size controls. Screenshots were saved and inspected. Raw observations, including the sparse-list issue before correction, are in `qa/browser-measurements.json`; source results are in `qa/source-check.json`. Firefox and Safari were not physically run in this pass. Native control, focus and reduced-motion behavior remain inherited from the preserved app.

Saved source release: `dist/list-rhythm-1.0.0.zip`, with an internal file manifest and adjacent SHA-256 checksum. The earlier source releases remain unchanged.
