# List Rhythm · desktop event headings

Preserve all previous studies, source archives, app and kit. This sibling uses Pinned Apply's Half Split shell. Desktop only: keep the existing 24px top gap, double the bottom gap to 48px, and align the original Apply/Clear action row's bottom with the results panel's bottom. Do not put the right event in a scroll container.

Lineup, Calendar and Month Index vary only the event list's summary/month heading composition. Cards and event details remain unchanged. Reuse the existing result status node, month headings/counts, jump links and Badge. Keep all IDs, native link targets, filtering hooks and live status semantics. Private classes and semantic tokens own experimental CSS; do not edit kit/component sources, define raw primitive values or register a new component. All desktop DOM enhancements restore below 75rem.

Use Python -B and this folder's tools. Never invoke any parent/app/kit writer. Preview at port4187/list-rhythm/index.html using the existing server. Save evidence and releases here. Do not publish.

Latest preference: Lineup is the selected favorite in this collection. Its desktop Apply dock now uses 24px above the action row (previously 16px), keeping the controls aligned with the results panel bottom and the 48px viewport clearance. Calendar, Month Index and the original 1.0.0 source archive remain preserved.
