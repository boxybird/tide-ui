# Tide in use

A mobile-first, static HTML/CSS app study using the approved Tide kit. The original `../tide-ui-kit/` is preserved. A reviewed copy is included in `kit/`.

Start `node server.cjs`, then open http://127.0.0.1:4186/review.html. Open `index.html` for the actual responsive app. All pages also work directly from disk.

## Review

- `review.html`: browse at phone, portrait tablet and desktop sizes.
- `event-review.html`: the full event at the same sizes.
- `search-review.html` and `submit-review.html`: additional compositions.
- Six named theme/mode directories use identical markup and layout: Tide, Summer and Bumble, each dark/light. Root pages are Tide dark.
- `kit/index.html`: reviewed component library, preserved foundations and all previous screen specimens.

The comparison page scales actual HTML iframes for inspection. Use **Open app** to try the real page at the width of your browser. Screenshots are in `qa/`.

## Source

- `data/events.json`: three fictional events, shared across all routes.
- `tools/build.py`: deterministic HTML generation; no runtime framework or browser scripts.
- `css/app.css`: layout compositions, importing component geometry and semantic colors from `kit/css/tide.css`.
- `css/review.css`: review presentation only, not part of the product.
- `kit/css/`, `kit/tokens/`, `kit/templates/`: reviewed kit source.
- `docs/REVIEW.md`: code/accessibility findings and limits.
- `docs/RESPONSIVE.md`: responsive behavior, extension contract and PWA considerations.

To rebuild, run `python kit/tools/build.py` then `python tools/build.py` from this directory. To validate:

```
python kit/tools/build.py --check
python kit/tools/check.py
python -m unittest discover -s kit/tools -p "test_*.py"
python tools/build.py --check
python tools/check.py
```

No dependencies need downloading. Python 3 and Node.js are only build/preview tools; the delivered HTML/CSS is portable.

## Scope

Event navigation, anchored details, native filter disclosures, reset buttons and form inputs work. Search and saved lists are fixed examples. The form does not send anything. There are no reservations, accounts, persistent bookmarks, installations, offline cache or service worker. The PWA product work follows once the responsive design is selected.
